package com.example.retrofitdemo2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.viewbinding.ViewBinding
import com.example.retrofitdemo2.api.ApiClient
import com.example.retrofitdemo2.databinding.ActivityMainBinding
import com.example.retrofitdemo2.databinding.ItemPostBinding
import com.example.retrofitdemo2.listener.OnViewListener
import com.example.retrofitdemo2.listener.PostClickListener
import com.example.retrofitdemo2.model.Post
import retrofit2.Call
import retrofit2.Response
import javax.security.auth.callback.Callback

class MainActivity : AppCompatActivity(), OnViewListener{
    var adapter: PostAdapter? = null
    var binding: ActivityMainBinding? = null
    var post = ArrayList<Post>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        adapter = PostAdapter(this, this)
        binding!!.post.adapter = adapter
        getPost()
    }

    fun getPost() {
        val call = ApiClient.apiService.getPost()
        call.enqueue(object : Callback, retrofit2.Callback<ArrayList<Post>> {
            override fun onResponse(
                call: Call<ArrayList<Post>>,
                response: Response<ArrayList<Post>>
            ) {
                Log.e("PostReponse", response.body().toString())
                post = response.body()!!
                adapter!!.update(post)
            }

            override fun onFailure(call: Call<ArrayList<Post>>, t: Throwable) {
                Log.e("Post Failure", t.message!!)
            }

        })
    }

    override fun ItemView(position: Int) {
        var intent = Intent(this, PostDetailActivity::class.java)
        intent.putExtra("post_id", post[position].id.toString())
        startActivity(intent)
    }
}