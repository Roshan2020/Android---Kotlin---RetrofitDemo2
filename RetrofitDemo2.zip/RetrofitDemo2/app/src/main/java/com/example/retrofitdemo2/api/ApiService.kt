package com.example.retrofitdemo2.api

import com.example.retrofitdemo2.model.Comment
import com.example.retrofitdemo2.model.Post
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface ApiService {
    @GET("posts")
    fun getPost(): retrofit2.Call<ArrayList<Post>>

    @GET("posts/{id}")
    fun getPostDetail(
        @Path("id") id :String
    ): Call<Post>

    @GET("posts/{id}/comments")
    fun getPostComments(
        @Path("id") id :String
    ): Call<ArrayList<Comment>>

    @POST("posts")
    fun postDetails(
        @Body data: HashMap<String, Any>
    ): Call<Post>
}
