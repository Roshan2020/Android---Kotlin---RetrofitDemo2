package com.example.retrofitdemo2

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.retrofitdemo2.databinding.ItemPostBinding
import com.example.retrofitdemo2.listener.OnViewListener
import com.example.retrofitdemo2.listener.PostClickListener
import com.example.retrofitdemo2.model.Comment
import com.example.retrofitdemo2.model.Post

class CommentsAdapter (var context: Context) : RecyclerView.Adapter<CommentsAdapter.PostViewHolder>(){
    inner class PostViewHolder(itemView: ItemPostBinding) : RecyclerView.ViewHolder(itemView.root)
    var binding: ItemPostBinding? = null
    var comments = ArrayList<Comment>()


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        binding = ItemPostBinding.inflate(inflater, parent, false)
        return PostViewHolder(binding!!)
    }

    override fun getItemCount(): Int {
        return comments.size
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        binding!!.tvTitle.text = comments[position].name
        binding!!.tvDescription.text = comments[position].body
    }

    fun update(list: ArrayList<Comment>){
        comments = list
        notifyDataSetChanged()
    }

}