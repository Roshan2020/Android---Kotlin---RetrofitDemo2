package com.example.retrofitdemo2

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.retrofitdemo2.databinding.ItemPostBinding
import com.example.retrofitdemo2.listener.OnViewListener
import com.example.retrofitdemo2.listener.PostClickListener
import com.example.retrofitdemo2.model.Post

class PostAdapter (var context: Context, var listener: OnViewListener) : RecyclerView.Adapter<PostAdapter.PostViewHolder>(){
    inner class PostViewHolder(itemView: ItemPostBinding) : RecyclerView.ViewHolder(itemView.root)
    var binding: ItemPostBinding? = null
    var posts = ArrayList<Post>()


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        binding = ItemPostBinding.inflate(inflater, parent, false)
        return PostViewHolder(binding!!)
    }

    override fun getItemCount(): Int {
        return posts.size
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        binding!!.tvTitle.text = posts[position].title
        binding!!.tvDescription.text = posts[position].body
        holder.itemView.setOnClickListener{listener.ItemView(position)}
    }

    fun update(list: ArrayList<Post>){
        posts = list
        notifyDataSetChanged()
    }

}