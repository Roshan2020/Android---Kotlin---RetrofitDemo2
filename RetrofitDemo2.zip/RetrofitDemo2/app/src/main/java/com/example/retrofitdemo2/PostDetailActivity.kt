package com.example.retrofitdemo2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.example.retrofitdemo2.api.ApiClient
import com.example.retrofitdemo2.databinding.ActivityMainBinding
import com.example.retrofitdemo2.databinding.ActivityPostDetailBinding
import com.example.retrofitdemo2.model.Post
import retrofit2.Call
import retrofit2.Response
import javax.security.auth.callback.Callback

class PostDetailActivity : AppCompatActivity() {
    var binding: ActivityPostDetailBinding? = null
    var postId: String? = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPostDetailBinding.inflate(layoutInflater)
        setContentView(binding!!.root)

        if (intent.hasExtra("post_id")){
            postId = intent.getStringExtra("post_id")
            getPostData(postId!!)
        }
        binding!!.post.setOnClickListener{ postData() }
        binding!!.btnComment.setOnClickListener{
            var intent = Intent(this, CommentsActivity::class.java)
            intent.putExtra("post_id", postId)
            startActivity(intent)
        }
    }

    fun getPostData(id: String){
        var call = ApiClient.apiService.getPostDetail(id)
        call.enqueue(object: Callback, retrofit2.Callback<Post>{
            override fun onResponse(call: Call<Post>, response: Response<Post>) {
                binding!!.tvTitle.text = response.body()!!.title
                binding!!.tvDescription.text = response.body()!!.body
            }

            override fun onFailure(call: Call<Post>, t: Throwable) {
                Log.e("Post Details Error", t.message!!)
            }
        })
    }

    fun postData(){
        var map: HashMap<String, Any> = HashMap()
        map.put("title", "userDemo1")
        map.put("body", "Demo Test User")
        map.put("id", 1)
        var call = ApiClient.apiService.postDetails(map)
        call.enqueue(object: Callback, retrofit2.Callback<Post> {
            override fun onResponse(call: Call<Post>, response: Response<Post>) {
                Toast.makeText(this@PostDetailActivity,"success", Toast.LENGTH_SHORT).show()
            }

            override fun onFailure(call: Call<Post>, t: Throwable) {
                Toast.makeText(this@PostDetailActivity,"failure", Toast.LENGTH_SHORT).show()
            }
        })
    }


}