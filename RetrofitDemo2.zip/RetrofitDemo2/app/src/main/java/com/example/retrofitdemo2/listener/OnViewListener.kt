package com.example.retrofitdemo2.listener

interface OnViewListener {
    fun ItemView(postion: Int)
}