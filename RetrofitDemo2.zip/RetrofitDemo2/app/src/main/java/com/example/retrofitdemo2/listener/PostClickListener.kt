package com.example.retrofitdemo2.listener

interface PostClickListener {
    fun onPostClick(position: Int)
}