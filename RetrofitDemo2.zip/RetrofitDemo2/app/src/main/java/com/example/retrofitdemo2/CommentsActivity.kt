package com.example.retrofitdemo2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.retrofitdemo2.api.ApiClient
import com.example.retrofitdemo2.databinding.ActivityCommentsBinding
import com.example.retrofitdemo2.model.Comment
import retrofit2.Call
import retrofit2.Response
import javax.security.auth.callback.Callback

class CommentsActivity : AppCompatActivity() {
    var binding: ActivityCommentsBinding? = null
    var postId: String? = ""
    var adapter: CommentsAdapter? = null
    var comments: ArrayList<Comment>? = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCommentsBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        adapter = CommentsAdapter(this)
        binding!!.rvComments.adapter = adapter

        if (intent.hasExtra("post_id")){
            postId = intent.getStringExtra("post_id")
            getComments(postId!!)
        }
    }

    fun getComments(id: String){
        var call = ApiClient.apiService.getPostComments(id)
        call.enqueue(object: Callback, retrofit2.Callback<ArrayList<Comment>> {
            override fun onResponse(call: Call<ArrayList<Comment>>, response: Response<ArrayList<Comment>>) {
                comments = response.body()
                adapter!!.update(comments!!)
            }

            override fun onFailure(call: Call<ArrayList<Comment>>, t: Throwable) {

            }

        })
    }
}